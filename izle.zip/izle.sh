#!/bin/bash

# Screen oturumlarını başlat ve izletliste.py'yi çalıştır, 10 saniye bekle
for i in {1..8}; do
    screen -dmS izle$i bash -c "python3 izletliste.py; exec bash"
    echo "izle$i oturumu başlatıldı. 305 saniye bekleniyor..."
    sleep 305
done

# Mevcut oturumları listele
screen -ls

echo "8 adet screen oturumu sırayla başlatıldı."
