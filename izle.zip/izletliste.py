import undetected_chromedriver as uc
import chromedriver_autoinstaller
import time
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.common.exceptions import NoSuchElementException, WebDriverException
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options

# ChromeDriver'ı Chrome sürümüne göre otomatik olarak yükler
chromedriver_autoinstaller.install()

# Chrome seçeneklerini yapılandır
options = Options()
options.add_argument("--headless")  # Tarayıcıyı görünmez modda çalıştır
options.add_argument("--disable-gpu")
options.add_argument("--disable-dev-shm-usage")
options.add_argument("--no-sandbox")
options.add_argument("--disable-extensions")
options.add_argument("--disable-infobars")
options.add_argument("--disable-popup-blocking")
options.add_argument("--disable-notifications")
options.add_argument("--disable-logging")
options.add_argument("--log-level=3")
options.add_argument("--user-agent=Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.6261.128 Safari/537.36")

# Video isimlerinin listesi 'izlenecek.txt' dosyasından okunuyor
with open('izlenecek.txt', 'r', encoding='utf-8') as f:
    video_names = [line.strip() for line in f.readlines()]

try:
    # Tarayıcıyı başlat
    driver = uc.Chrome(options=options)

    # Gmail giriş sayfasına git
    driver.get("https://accounts.google.com/signin")

    # Kullanıcının manuel olarak giriş yapmasını bekle
    print("Lütfen Gmail'e giriş yapın ve ardından devam etmek için enter tuşuna basın.")
#    input()  # Kullanıcının enter tuşuna basmasını bekler

    # Videoları sırayla arayıp izleme işlemi yapıyoruz
    for video_name in video_names:
        print(f"'{video_name}' videosu aranıyor...")

        # YouTube'a tekrar gitme
        driver.get("https://www.youtube.com")
        time.sleep(10)  # YouTube'un yüklenmesi için bekle

        # Çerez kabul butonuna tıklama
        try:
            # Accept all butonunu tıklanabilir olana kadar bekle
            accept_cookies_button = WebDriverWait(driver, 20).until(
                EC.element_to_be_clickable((By.XPATH, "//button[@aria-label='Accept the use of cookies and other data for the purposes described']"))
            )
            accept_cookies_button.click()
            print("Çerezler kabul edildi.")
            time.sleep(10)  # Buton tıklaması sonrası bekle
        except NoSuchElementException:
            print("Çerez kabul butonu bulunamadı veya zaten kabul edilmiş.")
        except WebDriverException as e:
            print(f"Çerez kabul işlemi sırasında bir hata oluştu: {e}.")

        # YouTube'da arama yapma
        try:
            # Arama kutusunu bul ve video ismini gir
            search_box = WebDriverWait(driver, 20).until(
                EC.presence_of_element_located((By.XPATH, "//input[@id='search']"))
            )
            search_box.clear()  # Önceki arama sonuçlarını temizler
            search_box.send_keys(video_name)  # Video adını yaz
            time.sleep(2)

            # Enter tuşuna bas
            search_box.send_keys(Keys.RETURN)
            print(f"'{video_name}' videosu için arama yapıldı.")
            time.sleep(10)  # Sonuçlar yüklenirken bekle

            # İlk çıkan videoya tıklama
            first_video = WebDriverWait(driver, 20).until(
                EC.element_to_be_clickable((By.CSS_SELECTOR, 'ytd-video-renderer #video-title'))
            )
            first_video.click()
            print(f"'{video_name}' videosu başlatıldı.")
            time.sleep(10)  # Video yüklenirken bekle

            # 200 saniye video izleme
            print(f"'{video_name}' videosu izleniyor (200 saniye)...")
            time.sleep(200)

            # Oynatma ve duraklatma işlemi
            video_element = driver.find_element(By.CSS_SELECTOR, 'video')
            is_paused = driver.execute_script("return arguments[0].paused;", video_element)

            if not is_paused:  # Oynuyorsa duraklat
                video_element.click()  # Video elementine direkt tıklayarak duraklat
                print(f"{video_name} videosu duraklatıldı.")
                time.sleep(10)  # Duraklatmadan sonra 10 saniye bekle
                video_element.click()  # Tekrar başlat
                print(f"{video_name} videosu tekrar başlatıldı.")
            else:
                video_element.click()  # Video duraklatılmışsa başlat
                print(f"{video_name} videosu başlatıldı.")
                time.sleep(10)  # Başlatmadan sonra 10 saniye bekle
        except NoSuchElementException:
            print(f"{video_name} videosunda oynatma/duraklatma işlemi yapılamadı.")
        except WebDriverException as e:
            print(f"'{video_name}' videosunda bir hata oluştu: {e}. Bir sonrakine geçiliyor.")
            continue

        # Sayfayı birkaç defa aşağı kaydır
        try:
            for _ in range(2):  # 2 kez aşağı kaydır
                driver.execute_script("window.scrollBy(0, window.innerHeight);")
                time.sleep(10)  # Her kaydırma arasında 10 saniye bekle

            # Aşağı kaydırma işlemi tamamlandıktan sonra sayfanın en üstüne çık
            driver.execute_script("window.scrollTo(0, 0);")
            time.sleep(10)  # En üste çıkıldıktan sonra 10 saniye bekle
        except WebDriverException as e:
            print(f"Sayfayı kaydırırken bir hata oluştu: {e}.")
        
        # 90 saniye daha bekleyip diğer videoya geç
        print(f"'{video_name}' videosundan sonra 90 saniye bekleniyor...")
        time.sleep(90)

        # Çerezleri temizle
        try:
            driver.delete_all_cookies()
            print(f"{video_name} videosundan sonra çerezler temizlendi.")
        except WebDriverException as e:
            print(f"Çerezler temizlenirken bir hata oluştu: {e}.")

finally:
    # Tarayıcıyı manuel olarak kapatma
    try:
        driver.quit()
        print("Tarayıcı düzgün bir şekilde kapatıldı.")
    except Exception as e:
        print(f"Tarayıcı kapatılırken hata oluştu: {e}")
